<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->

<?php 

include 'config.php';
include('session.php');


?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Skillset</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">


  <link rel="icon" type="image/x-icon" href="assets/images/icon.png">
</head>
<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
  <?php
include('Navbar_Cust.php');


?>
  <!-- /.navbar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">

      <br/>  <br/>
     
     
            <ol class="breadcrumb" style="padding-left: 20%;">
              <li class="breadcrumb-item"><a href="index.php#services"><i class="fa fa-home"></i></a></li>
             
                  <li class="breadcrumb-item active">Orders</li>
            </ol>
         <div class="container">

            <div align="right">
            <a href="Order_History.php" class="btn btn-dark">Order History</a>

          </div>
          <br/>
          <div class="card">
            <table id="example2" class="table table-bordered table-hover dataTable dtr-inline" aria-describedby="example2_info">
                  <thead>
                  <tr><th class="sorting sorting_asc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Date</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">Item</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">Freelancer</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending">Plan</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending">Amount</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending">Status</th>

                    <th>Action</th></tr>
                  </thead>
                  <tbody>

                             <?php
$fld_Id=$_SESSION['login_user'];






if (isset($_POST['rating'])) {


    $fld_order_Id=$_POST['fld_order_Id'];
    $fld_rating=$_POST['fld_rating'];
$fld_review=$_POST['fld_review'];

    $sqlq ="UPDATE tbl_orders SET fld_status='Closed', fld_rating='$fld_rating' , fld_review='$fld_review' WHERE fld_order_Id='$fld_order_Id'";


if ($conn->query($sqlq) === TRUE) {

?>
 <script type="text/javascript">
window.onload = function(){
     
$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Orders.php";
    }, 3000);

            Swal.fire(
 'Review Submitted!',
    '',
  'success'
)
});

} </script>

     <?php

}else{

      echo "<td>Error Updating record: " . mysqli_error($conn);
}

}
      

$sql = "SELECT * FROM  tbl_user inner join tbl_orders on tbl_orders.fld_customer_Id=tbl_user.fld_Id inner join tbl_entry on tbl_entry.fld_entry_Id=tbl_orders.fld_entry_Id inner join tbl_jobs on tbl_jobs.fld_job_Id=tbl_entry.fld_job_Id  where tbl_user.fld_Id='$fld_Id' and tbl_orders.fld_status!='Closed' order by tbl_orders.fld_date DESC ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {

                        $date=$row['fld_date'];

                      

 ?>
                  <tr class="odd">
                    <td ><?php echo date('F j, Y H:i', strtotime($date)) ?></td>
                    <td><?php echo $row['fld_job'] ?></td>

<?php 

$entry_Id=$row['fld_entry_Id'];
$sql2 = "SELECT * FROM  tbl_user inner join tbl_entry on tbl_entry.fld_Id=tbl_user.fld_Id  where tbl_entry.fld_entry_Id='$entry_Id' ";

        $result2 = mysqli_query($conn,$sql2);
 $rowcount2=mysqli_num_rows($result2);


                      while($row2 = mysqli_fetch_assoc($result2)) {

                        $fld_Freelance_Pic=$row2['fld_pic'];
?>
                     <td><?php echo $fld_FN=$row2['fld_Firstname']." ". $row2['fld_Lastname']; } ?></td>
                       <td><?php echo  $row['fld_plan']; ?></td>
                        <td><?php echo "₹". $row['fld_amount']; ?></td>
                   <td style="color:green"><?php echo  $row['fld_status']; ?></td>
                   <td><a href="Job_Details.php?id=<?php echo $row['fld_entry_Id'] ?>" class="btn btn-dark btn-sm">See Order Details</a>

                    <?php
                    if($row['fld_status']=='Done'){

                      ?>
                     
                      
                     
                      <button class="btn btn-dark btn-sm"  data-toggle="modal" data-target="#largeModal<?php echo $row['fld_order_Id']?>"> Rate</button>
                         <div class=" modal fade" id="largeModal<?php echo $row['fld_order_Id']?>" tabindex="-1" role="dialog" aria-labelledby="defaultModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-m" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="defaultModalLabel">Rate the work of <b><?php echo $fld_FN ?></b> </h5>
                    

                            </div> 





                            <div class="modal-body">
                                  <img src="assets/images/users/<?php echo $fld_Freelance_Pic?>"  height="100px" width="100px" style="margin-left: 40%; border-radius: 50%;">
                                 <br/><br/> <h5 align="center"><?php echo $row['fld_job'] ?></h5>
                                 

                               <form action="#" method="post">

                                <input type="hidden" name="fld_order_Id" value="<?php echo $row['fld_order_Id'] ?>">
<style type="text/css">
  
  .rate {
    float: left;
    height: 46px;
    padding: 0 10px;
    padding-left: 35%;
}
.rate:not(:checked) > input {
    position:absolute;
    top:-9999px;
}
.rate:not(:checked) > label {
    float:right;
    width:1em;
    overflow:hidden;
    white-space:nowrap;
    cursor:pointer;
    font-size:30px;
    color:#ccc;
}
.rate:not(:checked) > label:before {
    content: '★ ';
}
.rate > input:checked ~ label {
    color: #ffc700;    
}
.rate:not(:checked) > label:hover,
.rate:not(:checked) > label:hover ~ label {
    color: #deb217;  
}
.rate > input:checked + label:hover,
.rate > input:checked + label:hover ~ label,
.rate > input:checked ~ label:hover,
.rate > input:checked ~ label:hover ~ label,
.rate > label:hover ~ input:checked ~ label {
    color: #c59b08;
}
</style>

                                <div class="rate">
    <input type="radio" id="star5" name="fld_rating" value="5" required />
    <label for="star5" title="text">5 stars</label>
    <input type="radio" id="star4" name="fld_rating" value="4" required />
    <label for="star4" title="text">4 stars</label>
    <input type="radio" id="star3" name="fld_rating" value="3" required/>
    <label for="star3" title="text">3 stars</label>
    <input type="radio" id="star2" name="fld_rating" value="2"required />
    <label for="star2" title="text">2 stars</label>
    <input type="radio" id="star1" name="fld_rating" value="1"required />
    <label for="star1" title="text">1 star</label>
  </div>

  <br/> <br/>
  <div align="center">

    <textarea placeholder="Write a Review" name="fld_review"  rows="5" cols="60" required="required"></textarea>
      <input type="submit" class="btn-dark btn-sm" name="rating" value="Rate">
    </div>
                                  </form>




                      
                            </div> 
                          </div>
                        </div>
                      </div>


                      <?php
                    }else{



                    }




                      ?>




                   </td>
                  </tr>


                  <?php 


                }

                ?>

                </tbody>
                
                </table>





          </div>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer" align="center">
    <!-- To the right -->
  
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="index.php">Skillset</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

</body>
</html>
