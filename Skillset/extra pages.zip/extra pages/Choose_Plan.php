<!DOCTYPE html >
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Order</title>

<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <link rel="icon" type="image/x-icon" href="assets/images/icon.png">

<?php

 include("config.php");


if ($_SERVER["REQUEST_METHOD"] == "POST" ) {

  



    $fld_entry_Id=$_POST['fld_entry_Id'];

    $fld_Id=$_POST['fld_Id'];

    $fld_plan=$_POST['fld_Plan'];
    $fld_amount=$_POST['fld_amount'];







$sqlq = "INSERT INTO tbl_orders (fld_entry_Id, fld_customer_Id, fld_plan,fld_amount) 
    VALUES ('$fld_entry_Id', '$fld_Id', '$fld_plan','$fld_amount') ;";
  



          
if ($conn->query($sqlq) === TRUE) {




   ?>
 <script type="text/javascript">
window.onload = function(){
     



$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = 'Job_Details.php?id=<?php echo $fld_entry_Id ?>';
    }, 4000);

            Swal.fire(
 'Order Sucessful',
    '',
  'success'
)
});

} </script>

     <?php






}else{



      echo "<td>Error updating record: " . mysqli_error($conn);
}












 }





?>








  


  <script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- SweetAlert2 -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>