 
   <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">

 <nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
    <div class="container">
      <a href="logout.php" class="navbar-brand">
        <img src="assets/images/icon.png" alt="Skillset Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">Skillset</span>
      </a>

  

      <div class="collapse navbar-collapse " id="navbarCollapse">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="logout.php" class="nav-link">Home</a>
          </li>

         
         
         
    
        </ul>

     <div style="padding-left:50%">
           <?php 
     if(!isset($_SESSION['login_user'])){

      ?>

<div style="padding-left:60%">
          
    <button id="lgn" data-toggle="modal" data-target="#varyModal" data-whatever="@mdo" class="btn btn-dark btn-outline">Login</button>


</div>  


     <?php

    

    }else{

$fld_Id=$_SESSION['login_user'];



$sql = "SELECT * FROM tbl_user where fld_Id='$fld_Id' ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {

?>
   <ul class="navbar-nav">


   <a href="My_Ads.php" class="nav-link">My Ads</a>
         

   <?php 

  $sql3 = "SELECT * FROM  tbl_chat where fld_sender='$fld_Id'  or fld_receiver='$fld_Id' ";

        $result3 = mysqli_query($conn,$sql3);
 $rowcount3=mysqli_num_rows($result3);


 if($rowcount3>=1){


?>

    <li class="nav-item">
      <a href="Inbox.php" class="nav-link">Inbox </a>
    </li>

    <?php 
}else{

}

?>
            <a href="Todo.php" class="nav-link">To-do</a>
        

        <a href="Account_Free.php">      <img src="assets/images/users/<?php echo$row['fld_pic'];?>" height="40px" style="border-radius: 50%;">

<?php echo $row['fld_Firstname'] ?></a>


       <li class="nav-item" style="padding-left:20px">
   <a href="logout.php" class="btn btn-dark btn-outline">Logout</a>
 </li>

<?php

                      }


    }

?>
  


</div>  

        <!-- SEARCH FORM -->
       
      </div>

  
    </div>
  </nav>


  <script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
