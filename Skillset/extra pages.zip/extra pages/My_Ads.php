<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->

<?php 

include 'config.php';
require('session.php');

?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Skillset</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

   <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">

  <link rel="icon" type="image/x-icon" href="assets/images/icon.png">
</head>
<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
<?php 



include('Navbar_Free.php');


?>
  <!-- /.navbar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">

      <br/>  <br/>
          


<?php





        $fld_Id=$_SESSION['login_user'];

$sql = "SELECT * FROM tbl_entry inner join tbl_jobs on tbl_jobs.fld_job_Id=tbl_entry.fld_job_Id  where tbl_entry.fld_Id='$fld_Id' ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {
                      }

 ?>
     
            <ol class="breadcrumb" style="padding-left: 20%;">
         <li class="breadcrumb-item"><a href="index.php#services"><i class="fa fa-home"></i></a></li>
              <li class="breadcrumb-item active">My Ads</li>
            </ol>
         <div class="container">



        <br/>  

  <h2>My Advertisment</h2>

  <div align="right"> <button type="button" class="btn mb-1 btn-dark" data-toggle="modal" data-target="#varyModal" data-whatever="@mdo">
           Add Advertisment</button></div>



                <div class="modal fade" id="varyModal" tabindex="-1" role="dialog" aria-labelledby="defaultModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="defaultModalLabel">Add Advertisment</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>

                            </div> 





                           <form method="POST" action="Add_Entry.php" enctype="multipart/form-data" >  
                            <div class="modal-body">





             <div class="form-group row">
                
                         
                  
                        <label for="disabledInput" class="col-sm-4 col-form-label">Job Category </label>
                      
                         <div class="col-sm-8">




 <select  name="fld_job_Id" class="form-control select2"   required="required" style="width: 100%;"  onchange="lvl()">



<?php 




                    


$sql3 = "SELECT *
FROM tbl_jobs
WHERE fld_job_Id NOT IN (SELECT fld_job_Id FROM tbl_entry where fld_Id='$fld_Id');";

        $result3 = mysqli_query($conn,$sql3);
 $rowcount3=mysqli_num_rows($result3);


                      while($row3 = mysqli_fetch_assoc($result3)) {
                      


?>

        <option value="<?php echo $row3['fld_job_Id'] ?>"><?php echo $row3['fld_job']; ?></option>
   
<?php 


}
?>
                 
                  </select>
                  <code style="color:black">Note: you can only submit 1 entry per job category</code>

                </div>
              </div>





                       <div class="form-group row">

              
                  
                        <label for="disabledInput" class="col-sm-4 col-form-label">Heading</label>
                        <div class="col-sm-8">
                          <input class="form-control" type="text" name="fld_description" required="required">
                        </div>
                      </div>


                        <div class="form-group row">

              
                  
                        <label for="disabledInput" class="col-sm-4 col-form-label">About the Job</label>
                        <div class="col-sm-8">
                         <textarea required="required" name="fld_about" rows="10" cols="40"></textarea>
                        </div>
                      </div>


                      <hr><p align="center"><b>Prices</b></p>

                      <div class="form-group row">

                     <label for="disabledInput" class="col-sm-4 col-form-label">Basic</label>
                        <div class="col-sm-8">
                          <input class="form-control" type="text" name="fld_basic" required="required">
                        </div>
                      </div>


                       <div class="form-group row">

                     <label for="disabledInput" class="col-sm-4 col-form-label">Standard</label>
                        <div class="col-sm-8">
                          <input class="form-control" type="text" name="fld_standard" required="required">
                        </div>
                      </div>



                       <div class="form-group row">

                     <label for="disabledInput" class="col-sm-4 col-form-label">Premium</label>
                        <div class="col-sm-8">
                          <input class="form-control" type="text" name="fld_premium" required="required">
                        </div>
                      </div>
<hr>
                     
  <input type="hidden" name="fld_Id" value="<?php echo $fld_Id ?>">




 <div class="form-group row">
    <label for="disabledInput" class="col-sm-6 col-form-label">Main Ad Picture</label>
  <div class="custom-file col-sm-6">
                        <input type="file" name="fld_picture" required="required" id="up" class="custom-file-input" id="exampleInputFile">
                        <label class="custom-file-label " for="exampleInputFile" >Choose file</label>
                      </div>
                         
</div>

 </div>

                  
                            <div class="modal-footer">
                              <input type="submit" class="btn mb-2 btn-primary"  name="add" value="Add Advertisment">
                            </div> </form>
                          </div>
                        </div>
                      </div>
























<br/>  <br/>





       



<style>


/* Center website */
.main {
  max-width: 1000px;
  margin: auto;
}

h1 {
  font-size: 50px;
  word-break: break-all;
}

.row {
  margin: 10px -16px;
}

/* Add padding BETWEEN each column */
.row,
.row > .column {
  padding: 8px;
}

/* Create three equal columns that floats next to each other */


/* Clear floats after rows */ 
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Content */
.content {
  background-color: white;
  padding: 10px;
}

/* The "show" class is added to the filtered elements */
.show {
  display: block;
}

/* Style the buttons */



</style>
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">



<div id="myBtnContainer">
        

           <?php


$sql = "SELECT * FROM tbl_jobs inner join tbl_entry ON tbl_jobs.fld_job_Id=tbl_entry.fld_job_Id where tbl_entry.fld_Id='$fld_Id' ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);

 if (mysqli_num_rows($result) > 0) { 
  ?>
  <!-- <button class="btn " onclick="filterSelection('all')"> Show all</button>   -->

  <?php
                      while($row = mysqli_fetch_assoc($result)) {

                        ?>

  <!-- <button class="btn" onclick="filterSelection('<?php echo $row['fld_tags'] ?>')"> <?php echo $row['fld_tags'];} ?></button> -->


<?php 
}else{
?>
<h1 align="center">No entries yet</h1>
<?php
}
?>
</div>

<!-- Portfolio Gallery Grid -->
<div class="row">
         <?php


$sql = "SELECT * FROM tbl_jobs inner join tbl_entry ON tbl_jobs.fld_job_Id=tbl_entry.fld_job_Id inner join tbl_user on tbl_user.fld_Id=tbl_entry.fld_Id inner join tbl_portfolio on tbl_portfolio.fld_entry_Id=tbl_entry.fld_entry_Id where tbl_entry.fld_Id='$fld_Id' group by tbl_entry.fld_entry_Id ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);
 if (mysqli_num_rows($result) > 0) { 

                      while($row = mysqli_fetch_assoc($result)) {


                            ?> 

  <div class="col-md-3">
  <div class="column <?php echo $row['fld_tags'] ?>">
    <div class="content">

     
      <a href="#"  data-toggle="modal" data-target="#largeModal<?php echo $row['fld_entry_Id']?>">

      <img src="assets/images/entries/<?php echo $row['fld_picture'] ?>" alt="Mountains" style="width:100%"></a>
      <img src="assets/images/users/<?php echo $row['fld_pic'] ?>" style="border-radius: 50%; height: 20px;"> <code style="color: black; font-size: 20px; padding-left: 10px;"><?php echo $row['fld_Firstname']." ". $row['fld_Lastname'] ?></code>

      <?php 
     if(!isset($_SESSION['login_user'])){


?>
 <a href="#" data-toggle="modal" data-target="#varyModal" data-whatever="@mdo" class="txt" > <p><?php echo $row['fld_description']?></p></a>

          <div class=" modal fade" id="varyModal" tabindex="-1" role="dialog" aria-labelledby="defaultModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-m" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="defaultModalLabel">Login </h5>
                    

                            </div> 





                            <div class="modal-body">
                                  <img src="assets/images/icon.png"  height="100px" width="100px" style="margin-left: 40%;">

                                  <br/><br/>

                               <form action="#" method="post">
        <div class="input-group mb-3">
          <input type="email" class="form-control" placeholder="Email" name="fld_Username" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Password" name="fld_Password" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
         
          <!-- /.col -->
          <div class="col-12">
            <button type="submit" class="btn btn-dark btn-block">Log In</button>
             <a href="Register.php" class="btn btn-dark btn-block">Sign Up</a>
          </div>
          <!-- /.col -->
        </div>
      </form>




                      
                            </div> 
                          </div>
                        </div>
                      </div>
        

<?php 


}else{

  ?>
 <a href="#" class="txt" > <p><?php echo $row['fld_description']?></p></a>

<?php 
}

?>



    


     <style type="text/css">
      .txt{

        color: black;
      }
       
      .txt:hover {
        color: black;
    text-decoration: underline;
}

     </style>
      <i class="fa fa-star" ><i style="padding-left:10px; font-style:normal;"><?php echo $row['fld_rating']?></i></i>
      <p style="font-display: bold; font-size: 20px;">Starts ₹<?php echo $row['fld_basic']?></p>
    <a href="Edit_Ads.php?id=<?php echo $row['fld_entry_Id']?>" class="btn btn-dark btn-block">Edit Advertisment</a>



  <!-- modal -->
  <div class="modal fade" id="largeModal<?php echo $row['fld_entry_Id']?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-body">
           <!-- carousel -->

                           <?php

$fld_folio_Id=$row['fld_folio_Id'];
$sql2 = "SELECT * FROM  tbl_portfolio where fld_folio_Id='$fld_folio_Id'  ";

        $result2 = mysqli_query($conn,$sql2);
 $rowcount2=mysqli_num_rows($result2);


                      while($row2 = mysqli_fetch_assoc($result2)) {


                            ?> 
          <div
               id='carouselExampleIndicators'
               class='carousel slide'
               data-ride='carousel'
               >
          <ol class='carousel-indicators'>
              <li
                  data-target='#carouselExampleIndicators'
                  data-slide-to='0'
                  class='active'
                  ></li>
              <li
                  data-target='#carouselExampleIndicators'
                  data-slide-to='1'
                  ></li>
              <li
                  data-target='#carouselExampleIndicators'
                  data-slide-to='2'
                  ></li>
            </ol>
            <div class='carousel-inner'>
              <div class='carousel-item active'>

         
                <img  src='assets/images/entries/<?php echo $row2['fld_picture']; }?>' height="500px" width="100%" />
              </div>
           
            </div>
            <a
               class='carousel-control-prev'
               href='#carouselExampleIndicators'
               role='button'
               data-slide='prev'
               >
              <span class='carousel-control-prev-icon'
                    aria-hidden='true'
                    ></span>
              <span class='sr-only'>Previous</span>
            </a>
            <a
               class='carousel-control-next'
               href='#carouselExampleIndicators'
               role='button'
               data-slide='next'
               >
              <span
                    class='carousel-control-next-icon'
                    aria-hidden='true'
                    ></span>
              <span class='sr-only'>Next</span>
            </a>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
     
    </div>
  </div>
  <br/>

<!-- END GRID -->
</div>




<?php 

}
}else{



}

?>

</div>

<!-- END MAIN -->
</div>

<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>























<!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer" align="center">
    <!-- To the right -->
  
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="index.php">Skillset</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>

</body>
</html>
