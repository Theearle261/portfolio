<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->

<?php 

include 'config.php';
require('session.php');


?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Skillset</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

   <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">

  <link rel="icon" type="image/x-icon" href="assets/images/icon.png">
</head>
<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
  <?php


                if($fld_User_Level=='Customer'){



                

             
include('Navbar_Cust.php');


}else{

include('Navbar_Free.php');

}
include('Aside.php');





if (isset($_POST['send'])) {


    $fld_sender=addslashes($_POST['fld_sender']);
        $fld_receiver=addslashes($_POST['fld_receiver']);
            $fld_chat=addslashes($_POST['fld_chat']);


    $sqlq = "INSERT INTO tbl_chat (fld_chat, fld_receiver , fld_sender ) 
    VALUES ('$fld_chat', '$fld_receiver', '$fld_sender') ;";


if ($conn->query($sqlq) === TRUE) {

?>
 <script type="text/javascript">
window.onload = function(){
     
$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Convo.php?id=<?php echo $fld_receiver ?>";
    }, 4000);


});

} </script>

     <?php

}else{

      echo "<td>Error Updating record: " . mysqli_error($conn);
}

}



?>





                <?php
$fld_sender=$_GET['id'];
$fld_Id=$_SESSION['login_user'];
      

$sql = "SELECT * FROM  tbl_chat inner join tbl_user on tbl_user.fld_Id=tbl_chat.fld_sender where tbl_chat.fld_sender='$fld_sender' and tbl_chat.fld_receiver='$fld_Id'  Group by tbl_user.fld_Id order by tbl_chat.fld_Date ASC  ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {

                       
                     
                        ?> 





  <div class="content-wrapper" style="padding-left: 20%; padding-right:20%">
    <!-- Content Header (Page header) -->
    <div class="content-header">


      </div>

   <div class="card card-dark card-outline" >
    <div class="card-header">

    <h2> <img src="assets/images/users/<?php echo$row['fld_pic'];?>" height="40px" style="border-radius: 50%;"> <i style="font-style:normal; padding-left:10px;"><?php echo $row['fld_Firstname']." ".$row['fld_Lastname']; ?></i></h2>
  </div>
  <div class="card-body" style="overflow: auto; height: 500px; flex-direction: column-reverse;    display: flex;">
         <?php 



         $fld_sender=$row['fld_sender']; 
          $fld_receiver=$row['fld_receiver']; 




$sql2 = "SELECT * FROM  tbl_chat inner join tbl_user on tbl_user.fld_Id=tbl_chat.fld_sender where tbl_chat.fld_sender='$fld_sender' and tbl_chat.fld_receiver='$fld_Id'  or tbl_chat.fld_sender='$fld_Id' and tbl_chat.fld_receiver='$fld_sender' Order by  tbl_chat.fld_Date DEsC  ";

        $result2 = mysqli_query($conn,$sql2);
 $rowcount2=mysqli_num_rows($result2);


                      while($row2 = mysqli_fetch_assoc($result2)) {

         $fld_sender2=$row2['fld_sender']; 
          $fld_receiver2=$row2['fld_receiver']; 


          if($fld_sender2==$fld_Id){

            ?>
            <div class="row">

                 <div class="col-md-4">

                 </div>
              <div class="col-md-8">

            <div class="direct-chat-msg right">
                    <div class="direct-chat-infos clearfix">
                      <span class="direct-chat-name float-right"><?php echo $row2['fld_Firstname']." ".$row2['fld_Lastname']; ?></span>
                      <span class="direct-chat-timestamp float-left"><?php echo date('F j, y h:i ', strtotime($row2['fld_Date'])); ?></span>
                    </div>
                    <!-- /.direct-chat-infos -->
                    <img class="direct-chat-img" src="assets/images/users/<?php echo$row2['fld_pic'];?>" alt="Message User Image">
                    <!-- /.direct-chat-img -->
                    <div class="direct-chat-text">
                        <?php echo $row2['fld_chat'];?>
                    </div>
                    <!-- /.direct-chat-text -->
                  </div>

                </div>
              </div>


            <?php
          }else{

            ?>

         <div class="row">

               
              <div class="col-md-8">

            <div class="direct-chat-msg">
                    <div class="direct-chat-infos clearfix">
                      <span class="direct-chat-name float-left"><?php echo $row2['fld_Firstname']." ".$row2['fld_Lastname']; ?></span>
                      <span class="direct-chat-timestamp float-right"><?php echo date('F j, y h:i ', strtotime($row2['fld_Date'])); ?></span>
                    </div>
                    <!-- /.direct-chat-infos -->
                    <img class="direct-chat-img" src="assets/images/users/<?php echo$row2['fld_pic'];?>" alt="Message User Image">
                    <!-- /.direct-chat-img -->
                    <div class="direct-chat-text primary">
                        <?php echo $row2['fld_chat'];?>
                    </div>
                    <!-- /.direct-chat-text -->
                  </div>

                </div>  <div class="col-md-4">

                 </div>
              </div>

              <?php


          }

        }
         ?>


         


         
      
          </div>
         
         <div class="card-footer">
                <form action="#" method="post">
                  <div class="input-group">

                    <input type="hidden" name="fld_sender" value="<?php echo $_SESSION['login_user'] ?>">


                    <?php 
                    if($_SESSION['login_user']==$fld_receiver2){

                      ?>
                        <input type="hidden" name="fld_receiver" value="<?php echo $fld_sender2 ?>">
                        <?php
                    }else{
                      ?>

                        <input type="hidden" name="fld_receiver" value="<?php echo $fld_receiver2 ?>">

                      <?php
                    }

                    ?>
                   
                    <input type="text" name="fld_chat" autocomplete="off"  placeholder="Type Message ..." class="form-control">
                    <span class="input-group-append">
                      <button type="submit" class="btn btn-warning" name="send">Send</button>
                    </span>
                  </div>
                </form>
              </div>


        </div>

  

    
    </div> 

     <?php }

    ?>

  </div>



  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer" align="center">
    <!-- To the right -->
  
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="index.php">Skillset</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>

</body>
</html>
