
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
   
<div class="user-panel mt-3 pb-3 mb-3 ">
              <h2 align="center" style="color:white">Inbox</h2>
  </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div><div class="sidebar-search-results"><div class="list-group"><a href="#" class="list-group-item"><div class="search-title"><strong class="text-light"></strong>N<strong class="text-light"></strong>o<strong class="text-light"></strong> <strong class="text-light"></strong>e<strong class="text-light"></strong>l<strong class="text-light"></strong>e<strong class="text-light"></strong>m<strong class="text-light"></strong>e<strong class="text-light"></strong>n<strong class="text-light"></strong>t<strong class="text-light"></strong> <strong class="text-light"></strong>f<strong class="text-light"></strong>o<strong class="text-light"></strong>u<strong class="text-light"></strong>n<strong class="text-light"></strong>d<strong class="text-light"></strong>!<strong class="text-light"></strong></div><div class="search-path"></div></a></div></div>
      </div>

      <!-- Sidebar Menu -->
  
                                          <?php
$fld_Id=$_SESSION['login_user'];
      

$sql = "SELECT * FROM  tbl_chat inner join tbl_user on tbl_user.fld_Id=tbl_chat.fld_sender where tbl_chat.fld_receiver='$fld_Id' Group by tbl_user.fld_Id order by tbl_chat.fld_Date ASC  ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {

                        
                      
                        ?> 

   <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
 <li class="nav-item">
            <a href="Convo.php?id=<?php echo $row['fld_sender']  ?>" class="nav-link">
          <img src="../PC/assets/images/users/<?php echo$row['fld_pic'];?>" height="40px" style="border-radius: 50%;">
                        <p style="color:white"><?php echo $row['fld_Firstname']." ". $row['fld_Lastname'];  ?> </p>
                        </a>

                      </li>
            </ul> 

                        <?php 

                      }

                      ?>

          
         
  </aside>