 
   <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">

 <nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
    <div class="container">
      <a href="index.php" class="navbar-brand">
        <img src="assets/images/icon.png" alt="Skillset Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">Skillset</span>
      </a>

      <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse order-3" id="navbarCollapse">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="index.php" class="nav-link">Home</a>
          </li>
         
    
        </ul>

     <div style="padding-left:60%">
           <?php 
     if(!isset($_SESSION['login_user'])){

      ?>

<div style="padding-left:60%">
          
    <button id="lgn" data-toggle="modal" data-target="#varyModal" data-whatever="@mdo" class="btn btn-dark btn-outline">Login</button>


</div>  


     <?php

    

    }else{

$fld_Id=$_SESSION['login_user'];



$sql = "SELECT * FROM tbl_user where fld_Id='$fld_Id' ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {

?>
   <ul class="navbar-nav">

    <li class="nav-item">

        <?php 
    
      

$sql2 = "SELECT * FROM  tbl_orders where fld_customer_Id='$fld_Id' ";

        $result2 = mysqli_query($conn,$sql2);
 $rowcount2=mysqli_num_rows($result2);


 if($rowcount2!=0){




 ?>


  <span class="float-right badge badge-danger "><?php echo $rowcount2 ?></span><a href="Orders.php" class="nav-link">Orders </a>



  <?php
}else{

    ?>

<a href="Orders.php" class="nav-link">Orders </a>



<?php
}

  ?>

</li>
<?php 

  $sql3 = "SELECT * FROM  tbl_chat where fld_sender='$fld_Id'  or fld_receiver='$fld_Id' ";

        $result3 = mysqli_query($conn,$sql3);
 $rowcount3=mysqli_num_rows($result3);


 if($rowcount3>=1){


?>

    <li class="nav-item">
      <a href="Inbox.php" class="nav-link">Inbox </a>
    </li>

    <?php 
}else{

}

?>
         
      <a href="Account_Cust.php">      <img src="assets/images/users/<?php echo$row['fld_pic'];?>" height="40px" style="border-radius: 50%;">

<?php echo $row['fld_Firstname'] ?></a>


       <li class="nav-item" style="padding-left:20px">
   <a href="logout.php" class="btn btn-dark btn-outline">Logout</a>
 </li>

<?php

                      }


    }

?>
  


</div>  

        <!-- SEARCH FORM -->
       
      </div>

  
    </div>
  </nav>


  <script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
