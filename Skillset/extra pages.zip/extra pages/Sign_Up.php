<!DOCTYPE html >
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign Up</title>

<link rel="stylesheet" href=" plugins/fontawesome-free/css/all.min.css">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href=" plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href=" plugins/toastr/toastr.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href=" dist/css/adminlte.min.css">

<?php
ini_set('display_errors', 0); 
 include("config.php");
 require('session.php');


if ($_SERVER["REQUEST_METHOD"] == "POST" ) {


  
    $fld_Lastname=$_POST['fld_Lastname'];
        $fld_Firstname=$_POST['fld_Firstname'];
            $fld_Username=$_POST['fld_Username'];
             $fld_User_Level=$_POST['fld_User_Level'];
                $fld_Password=$_POST['fld_Password'];
                                $fld_Phone=$_POST['fld_Phone'];
                                                $fld_Address=$_POST['fld_Address'];


   $sqlab = "SELECT * FROM  tbl_user where fld_Username='$fld_Username'";

                           $resultab = mysqli_query($conn,$sqlab);
                            $rowcountab=mysqli_num_rows($resultab);
                          while($rowab = mysqli_fetch_assoc($resultab)) {

                        
                            }
                           if($rowcountab>=1){


                                                ?>
 <script type="text/javascript">
window.onload = function(){
     



$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Register.php";
    }, 4000);

            Swal.fire(
 'Account already exist! ',
    'Deactivate the existing before Adding a new one with the same  Username',
  'warning'
)
});

} </script>

     <?php
                           }else{










$sqlq = "INSERT INTO tbl_user (fld_Lastname, fld_Firstname, fld_Username, fld_Password, fld_Phone, fld_Address, fld_User_Level ) 
    VALUES ('$fld_Lastname', '$fld_Firstname', '$fld_Username', '$fld_Password', '$fld_Phone', '$fld_Address', '$fld_User_Level') ;";
  



          
if ($conn->query($sqlq) === TRUE) {



       $sql = "SELECT * FROM tbl_user WHERE fld_Username = '$fld_Username' and fld_Password = '$fld_Password' AND fld_User_Level!='Administrator' ";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
    
      if($count == 1) {

                    $fld_Firstname=$row['fld_Firstname'];
                   
                                $fld_Id=$row['fld_Id'];
                            
   

         $_SESSION['login_user'] = $fld_Id;


         if($fld_User_Level=='Customer'){

            ?>
 <script type="text/javascript">
window.onload = function(){
     



$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Account_Cust.php";
        document.getElementById('lgn').hidden=true;
    }, 4000);

            Swal.fire(
 'Login Successful',
    'Welcome   <?php echo $fld_Firstname ?>',
  'success'
)
});

}

 </script>



            <?php
         }else{


?>

 <script type="text/javascript">
window.onload = function(){
     



$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Account_Free.php";
        document.getElementById('lgn').hidden=true;
    }, 4000);

            Swal.fire(
 'Sign Up Successful',
    'Welcome   <?php echo $fld_Firstname ?>',
  'success'
)
});

}

 </script>
<?php 

}

}


  ?>


<!-- 

 <script type="text/javascript">
window.onload = function(){
     



$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Account.php";
    }, 4000);

            Swal.fire(
 'User Added',
    '',
  'success'
)
});

} </script> -->

     <?php






}else{



      echo "<td>Error updating record: " . mysqli_error($conn);
}






}




}





?>








  


  <script src=" plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src=" plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- SweetAlert2 -->
<script src=" plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src=" plugins/toastr/toastr.min.js"></script>
<!-- AdminLTE App -->
<script src=" dist/js/adminlte.min.js"></script>