<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->

<?php 

include 'config.php';
include('session.php');


?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Skillset</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">


  <link rel="icon" type="image/x-icon" href="assets/images/icon.png">
</head>
<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
  <?php


                if($fld_User_Level=='Customer'){



                

             
include('Navbar_Cust.php');


}else{

include('Navbar_Free.php');

}


?>
  <!-- /.navbar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">

      <br/>  <br/>
              <?php




        $fld_entry_Id=$_GET['id'];


if (isset($_POST['fld_description'])) {


    $fld_description=$_POST['fld_description'];


    $sqlq ="UPDATE tbl_entry SET fld_description='$fld_description' WHERE fld_entry_Id='$fld_entry_Id'";


if ($conn->query($sqlq) === TRUE) {

?>
 <script type="text/javascript">
window.onload = function(){
     
$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Edit_Ads.php?id=<?php echo $fld_entry_Id ?>";
    }, 4000);

            Swal.fire(
 'Updated!',
    '',
  'success'
)
});

} </script>

     <?php

}else{

      echo "<td>Error Updating record: " . mysqli_error($conn);
}

}



if (isset($_POST['fld_about'])) {


    $fld_about=$_POST['fld_about'];


    $sqlq ="UPDATE tbl_entry SET fld_about='$fld_about' WHERE fld_entry_Id='$fld_entry_Id'";


if ($conn->query($sqlq) === TRUE) {

?>
 <script type="text/javascript">
window.onload = function(){
     
$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Edit_Ads.php?id=<?php echo $fld_entry_Id ?>";
    }, 4000);

            Swal.fire(
 'Updated!',
    '',
  'success'
)
});

} </script>

     <?php

}else{

      echo "<td>Error Updating record: " . mysqli_error($conn);
}

}







if (isset($_POST['fld_price'])) {


    $fld_basic=$_POST['fld_basic'];

    $fld_standard=$_POST['fld_standard'];

    $fld_premium=$_POST['fld_premium'];


    $sqlq ="UPDATE tbl_entry SET fld_basic='$fld_basic', fld_standard='$fld_standard', fld_premium='$fld_premium'  WHERE fld_entry_Id='$fld_entry_Id'";


if ($conn->query($sqlq) === TRUE) {

?>
 <script type="text/javascript">
window.onload = function(){
     
$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Edit_Ads.php?id=<?php echo $fld_entry_Id ?>";
    }, 4000);

            Swal.fire(
 'Updated!',
    '',
  'success'
)
});

} </script>

     <?php

}else{

      echo "<td>Error Updating record: " . mysqli_error($conn);
}

}





if (isset($_POST['portfolio'])) {


    $fld_folio_Id=$_POST['fld_folio_Id'];


   $sqlq = "DELETE FROM tbl_portfolio WHERE fld_folio_Id = $fld_folio_Id";


if ($conn->query($sqlq) === TRUE) {

?>
 <script type="text/javascript">
window.onload = function(){
     
$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Edit_Ads.php?id=<?php echo $fld_entry_Id ?>";
    }, 4000);

            Swal.fire(
 'Deleted!',
    '',
  'success'
)
});

} </script>

     <?php

}else{

      echo "<td>Error Updating record: " . mysqli_error($conn);
}

}



if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['fld_picture'])) {


    
  $fld_avatar=$_FILES['fld_picture']['name'];
  $fld_size=$_FILES['fld_picture']['size'];
  $fld_tmp_name=$_FILES['fld_picture']['tmp_name'];
  $fld_error=$_FILES['fld_picture']['error'];


  if($fld_error === 0){


    if($fld_size> 205000000){

?>
 <script type="text/javascript">
window.onload = function(){
     



$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Edit_Ads.php?id=<?php echo $fld_entry_Id ?>";
    }, 4000);

            Swal.fire(
 'File too Large',
    '',
  'warning'
)
});

} </script>

     <?php



    }else{

      $img_ex= pathinfo($fld_avatar, PATHINFO_EXTENSION);
      $img_ex_lc=strtolower($img_ex);

      $allowed_exs=array("jpg","jpeg","png", "tiff");

      if(in_array($img_ex_lc,$allowed_exs)){


        $new_img_name= uniqid("IMG-", true).'.'.$img_ex_lc;

        $img_upload_path='assets/images/entries/'.$new_img_name;
        move_uploaded_file($fld_tmp_name,         $img_upload_path);




$sqlq = "INSERT INTO tbl_portfolio (fld_picture, fld_entry_Id) 
    VALUES ('$new_img_name','$fld_entry_Id') ;";
  



          
if ($conn->query($sqlq) === TRUE) {






?>
 <script type="text/javascript">
window.onload = function(){
     
$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Edit_Ads.php?id=<?php echo $fld_entry_Id ?>";
    }, 4000);

            Swal.fire(
 'Updated!',
    '',
  'success'
)
});

} </script>

     <?php

}else{

      echo "<td>Error Updating record: " . mysqli_error($conn);
}

}

}

}
}
















$sql = "SELECT * FROM tbl_entry inner join tbl_jobs on tbl_jobs.fld_job_Id=tbl_entry.fld_job_Id inner join tbl_user on tbl_user.fld_Id=tbl_entry.fld_Id  where tbl_entry.fld_entry_Id='$fld_entry_Id' ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {

 ?>
     
            <ol class="breadcrumb" style="padding-left: 20%;">
              <li class="breadcrumb-item"><a href="index.php#services"><i class="fa fa-home"></i></a></li>
              <li class="breadcrumb-item active"><a href="Entries.php?id=<?php echo $row['fld_job_Id'] ?>"><?php echo $row['fld_job']; ?></a></li>
                  <li class="breadcrumb-item active"><?php echo $row['fld_Firstname']." ". $row['fld_Lastname']; }?></li>
            </ol>
         <div class="container">


        <br/> 



       



<style>


/* Center website */
.main {
  max-width: 1000px;
  margin: auto;
}

h1 {
  font-size: 50px;
  word-break: break-all;
}

.row {
  margin: 10px -16px;
}

/* Add padding BETWEEN each column */
.row,
.row > .column {
  padding: 8px;
}

/* Create three equal columns that floats next to each other */


/* Clear floats after rows */ 
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Content */
.content {
  background-color: white;
  padding: 10px;
}

/* The "show" class is added to the filtered elements */
.show {
  display: block;
}

/* Style the buttons */


</style>
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">



<div id="myBtnContainer">
        

           <?php


$sql = "SELECT * FROM tbl_jobs inner join tbl_entry ON tbl_jobs.fld_job_Id=tbl_entry.fld_job_Id where tbl_entry.fld_entry_Id='$fld_entry_Id' ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);

 if (mysqli_num_rows($result) > 0) { 

                      while($row = mysqli_fetch_assoc($result)) {

                        ?>

  <!-- <button class="btn" onclick="filterSelection('<?php echo $row['fld_tags'] ?>')"> <?php echo $row['fld_tags'];} ?></button> -->


<?php 
}else{
?>
<h1 align="center">No entries yet</h1>
<?php
}
?>
</div>

<!-- Portfolio Gallery Grid -->
<div class="row">
         <?php


$sql = "SELECT * FROM tbl_jobs inner join tbl_entry ON tbl_jobs.fld_job_Id=tbl_entry.fld_job_Id inner join tbl_user on tbl_user.fld_Id=tbl_entry.fld_Id inner join tbl_portfolio on tbl_portfolio.fld_entry_Id=tbl_entry.fld_entry_Id where tbl_entry.fld_entry_Id='$fld_entry_Id' group by tbl_entry.fld_entry_Id ";

        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);
 if (mysqli_num_rows($result) > 0) { 

                      while($row = mysqli_fetch_assoc($result)) {


                            ?> 

  <div class="col-md-7">
    <form action="#" method="POST">
    <div class="row">
     <div class="col-md-10">

    <h4 style="font-weight: bold;"><input type="text" name="fld_description" class="form-control" value="<?php echo $row['fld_description']?>">   </h4>
      </div>
       <div class="col-md-2">
        <button class="btn btn-dark" onclick="this.form.submit()">Update</button>
       </div>
     </div>
   </form>
      <div class="row">
        <img src="assets/images/users/<?php echo $row['fld_pic'] ?>" style="border-radius: 50%; height: 50px;">

        <div class="col-md-4">
          <code style="color: black; font-size: 20px; "><?php echo $row['fld_Firstname']." ". $row['fld_Lastname']. "|"?></code>
          <br/>
          <i style="font-style:normal; font-size: 18px;"><?php echo $row['fld_Address']?></i>
            <br/>
          <i class="fa fa-star" ><i style="padding-left:10px; font-style:normal; font-size: 20px;"><?php echo $row['fld_rating']?></i></i>
        </div>
        <div class="col-md-4" align="left" style="padding-left: -10%;">
          <code style="color: grey; font-size: 20px; "><?php echo $row['fld_Phone'] ?></code> 
        
        </div>
        
         
      
      </div>



  

  <div class="column">
    <div class="content">


     
      <style>
* {box-sizing: border-box;}

img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */


/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}



/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>

<h2>My Portfolio<code>-Maximum of 4 images</code></h2>

<div class="row">
  <div class="col-md-8">
<div class="slideshow-container" style="padding-top:20%">
<?php
  $sql2 = "SELECT * FROM tbl_entry inner join tbl_portfolio on tbl_portfolio.fld_entry_Id=tbl_entry.fld_entry_Id where tbl_entry.fld_entry_Id='$fld_entry_Id' ";

        $result2 = mysqli_query($conn,$sql2);
 $rowcount2=mysqli_num_rows($result2);

 if (mysqli_num_rows($result2) > 0) { 

                      while($row2 = mysqli_fetch_assoc($result2)) {

                        ?>


<div class="mySlides fade">

  <img src="assets/images/entries/<?php echo $row2['fld_picture'] ?>" style="width:100%">
  <br/>
</div>


<?php 
}
}
?>



</div>


</div>




<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 3000); // Change image every 2 seconds
}
</script>


<div class="col-md-4">
     
<?php
  $sql3 = "SELECT * FROM tbl_entry inner join tbl_portfolio on tbl_portfolio.fld_entry_Id=tbl_entry.fld_entry_Id where tbl_entry.fld_entry_Id='$fld_entry_Id' ";

        $result3 = mysqli_query($conn,$sql3);
 $rowcount3=mysqli_num_rows($result3);



                      while($row3 = mysqli_fetch_assoc($result3)) {

                   

                       

  if($rowcount2==1){
?>



   
<img  src="assets/images/entries/<?php echo $row3['fld_picture'] ?>" height="100px"  />
  


</form>


<?php


  }else{

     ?>

    <form method="POST" action="#">
    <input type="hidden" name="fld_folio_Id" value="<?php echo $row3['fld_folio_Id'] ?>">
  <button onclick="this.form.submit()" style="border: none;" name="portfolio"> 
    <div class="image-container">
<img  src="assets/images/entries/<?php echo $row3['fld_picture'] ?>" height="80px"  />
   <div class="overlay"></div>
</div>
</button>

</form>


<?php 

}

}

if($rowcount2<=3){



?>



     <form method ="POST" action="#" enctype="multipart/form-data" >
  <div class="custom-file" align="center" style="overflow: hidden; height: 100px;"  >
     <div class="form-group row">
 <input type="hidden" name="fld_entry_Id" value="<?php echo $row['fld_entry_Id'] ?>">
    </div>
     
                        <input type="file" style="width:98px" name="fld_picture"  class="form control"   onchange="form.submit()">
                        <br/>
                        <label  ><p>Add Photo</p></label>
                      </div>


                <br/>
                <br/>

              </form>







<?php
} else{

  ?>




<?php
}





?>



<style type="text/css">

        .image-container {
            position: relative;
            width: 150px;
            height: 100px;
            overflow: hidden;
        }

        .image-container img {
            width: 100%;
            height: auto;
            display: block;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            background: rgba(0, 0, 0, 0.5);
            opacity: 0;
            transition: opacity 0.2s ease-in-out;
        }

         .overlay::after {
            content: 'Delete';
            color: white;
            font-size: 2em;
        }

        .image-container:hover .overlay {
            opacity: 1;
        }
  

</style>


</div>

</div>
    </div>
  </div>
  <br/>

  <h4>About this job</h4>
<form action="#" method="POST">
  <p style="font-size: 15px;"><textarea class="form-control" name="fld_about" rows="10" cols="50"><?php echo $row['fld_about'] ?></textarea></p>
 <button class="btn btn-dark btn-block" onclick="this.form.submit()">Update</button>

</form>

<!-- END GRID -->
</div>



<div class="col-md-5" style="padding-right: -50%;">
     <div class="card card-dark card-outline">

  <div class="card-body">
         
            <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="custom-content-below-home-tab" data-toggle="pill" href="#custom-content-below-home" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Basic</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="custom-content-below-profile-tab" data-toggle="pill" href="#custom-content-below-profile" role="tab" aria-controls="custom-content-below-profile" aria-selected="false">Standard</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#custom-content-below-messages" role="tab" aria-controls="custom-content-below-messages" aria-selected="false">Premium</a>
              </li>
               <li class="nav-item">
                <a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#custom-content-below-prices" role="tab" aria-controls="custom-content-below-messages" aria-selected="false">Edit Prices</a>
              </li>
             
            </ul>
            <div class="tab-content" id="custom-content-below-tabContent">
              <div class="tab-pane fade show active" id="custom-content-below-home" role="tabpanel" aria-labelledby="custom-content-below-home-tab">
                <br/>
          <div class="form-group row" style="padding-left:10%">
                    <h3>Light</h3>
                    <div class="col-sm-8" align="right">
                      <h3>
                     ₹<?php echo $row['fld_basic']?>
                   </h3>
                    </div>
                  </div>


<p style="font-size:20px;  padding-left:10px;">Includes 1 design concept with 3 revisions.</p>

<i class="fa fa-clock" style="padding-left:10px;"><i style="font-weight: bold; font-style: normal; font-size: 15px; padding-left:10px;">5 Days Delivery</i></i>

<i class="fa fa-sync" style="padding-left:60px"><i style="font-weight: bold; font-style: normal; font-size: 15px; padding-left:10px;">3 Revisions</i></i>
<br/><br/>

<i class="fa fa-check" style="padding-left:50px; "><i style="font-weight: normal; font-style: normal; font-size: 20px; padding-left:10px;">1 concept included</i></i>
<i class="fa fa-check" style="padding-left:50px; "><i style="font-weight: normal; font-style: normal; font-size: 20px; padding-left:10px;">Include Source File</i></i>

            <div class="tab-custom-content" style="padding-left:20px">
  <?php 
                if($fld_User_Level=='Customer'){



                

                ?>
              <form method="POST" action="Choose_Plan.php">

               <p align="justify">By proceeding, you acknowledge that you have read and agree to the Terms of Service and Privacy Policy. </p>


                <input type="hidden" name="fld_entry_Id" value="<?php echo $row['fld_entry_Id'] ?>">
                <input type="hidden" name="fld_Id" value="<?php echo $_SESSION['login_user'] ?>">
                 <input type="hidden" name="fld_Plan" value="Basic">
                 <input type="hidden" name="fld_amount" value="<?php echo $row['fld_basic'] ?>">
             <button onclick="this.form.submit()" class=" btn-block btn-dark">Choose this plan</button>
              </form>

               <?php 


            } else{

              
            }

            ?>
             
            </div>




              </div>
              <div class="tab-pane fade" id="custom-content-below-profile" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
                <br/>
          <div class="form-group row" style="padding-left:10%">
                    <h3>Solid</h3>
                    <div class="col-sm-8" align="right">
                      <h3>
                     ₹<?php echo $row['fld_standard']?>
                   </h3>
                    </div>
                  </div>

<p style="font-size:20px;  padding-left:10px;">Includes 2 initial design concepts. We refine and finalize the concept of your choice.</p>

<i class="fa fa-clock" style="padding-left:10px;"><i style="font-weight: bold; font-style: normal; font-size: 15px; padding-left:10px;">3 Days Delivery</i></i>

<i class="fa fa-sync" style="padding-left:60px"><i style="font-weight: bold; font-style: normal; font-size: 15px; padding-left:10px;">5 Revisions</i></i>
<br/><br/>

<i class="fa fa-check" style="padding-left:50px; "><i style="font-weight: normal; font-style: normal; font-size: 20px; padding-left:10px;">2 concept included</i></i>
<i class="fa fa-check" style="padding-left:50px; "><i style="font-weight: normal; font-style: normal; font-size: 20px; padding-left:10px;">Include Source File</i></i>


   <div class="tab-custom-content" style="padding-left:20px">
  <?php 
                if($fld_User_Level=='Customer'){



                

                ?>
              <form method="POST" action="Choose_Plan.php">

                   <p align="justify">By proceeding, you acknowledge that you have read and agree to the Terms of Service and Privacy Policy. </p>

                <input type="hidden" name="fld_entry_Id" value="<?php echo $row['fld_entry_Id'] ?>">
                <input type="hidden" name="fld_Id" value="<?php echo $_SESSION['login_user'] ?>">
                 <input type="hidden" name="fld_Plan" value="Standard">
                   <input type="hidden" name="fld_amount" value="<?php echo $row['fld_standard'] ?>">
             <button onclick="this.form.submit()" class=" btn-block btn-dark">Choose this plan</button>
              </form>

               <?php 


            } else{

              
            }

            ?>
             
            </div>

              </div>
              <div class="tab-pane fade" id="custom-content-below-messages" role="tabpanel" aria-labelledby="custom-content-below-messages-tab">
               <br/>
          <div class="form-group row" style="padding-left:10%">
                    <h3>Heavy</h3>
                    <div class="col-sm-8" align="right">
                      <h3>
                     ₹<?php echo $row['fld_premium']?>
                   </h3>
                    </div>
                  </div>

<p style="font-size:20px;  padding-left:10px;">Includes 3 initial design concepts. We refine and finalize the concept of your choice.</p>

<i class="fa fa-clock" style="padding-left:10px;"><i style="font-weight: bold; font-style: normal; font-size: 15px; padding-left:10px;">2 Days Delivery</i></i>

<i class="fa fa-sync" style="padding-left:60px"><i style="font-weight: bold; font-style: normal; font-size: 15px; padding-left:10px;">Unlimited Revisions</i></i>
<br/><br/>

<i class="fa fa-check" style="padding-left:50px; "><i style="font-weight: normal; font-style: normal; font-size: 20px; padding-left:10px;">3 concept included</i></i>
<i class="fa fa-check" style="padding-left:50px; "><i style="font-weight: normal; font-style: normal; font-size: 20px; padding-left:10px;">Include Source File</i></i>


   <div class="tab-custom-content" style="padding-left:20px">

                <?php 
                if($fld_User_Level=='Customer'){



                

                ?>
              <form method="POST" action="Choose_Plan.php">







                <p align="justify">By proceeding, you acknowledge that you have read and agree to the Terms of Service and Privacy Policy. </p>


                <input type="hidden" name="fld_entry_Id" value="<?php echo $row['fld_entry_Id'] ?>">
                <input type="hidden" name="fld_Id" value="<?php echo $_SESSION['login_user'] ?>">
                 <input type="hidden" name="fld_Plan" value="Premium">
                   <input type="hidden" name="fld_amount" value="<?php echo $row['fld_premium'] ?>">
             <button onclick="this.form.submit()" class=" btn-block btn-dark">Choose this plan</button>
              </form>

              <?php 


            } else{


            }

            ?>
             
            </div>

              </div>



                  <div class="tab-pane fade" id="custom-content-below-prices" role="tabpanel" aria-labelledby="custom-content-below-messages-tab">
               <br/>

               <form action="#" method="POST">
               <div class="row" style="padding-left:10%">
                  <div class="col-md-4">
                    <label>Basic</label>
                  </div>
                  <div class="col-md-6">
                    <input type="text" name="fld_basic" class="form-control" value="<?php echo $row['fld_basic'] ?>"required>
                  </div>

               </div>

               <div class="row" style="padding-left:10%">
                  <div class="col-md-4">
                    <label>Standard</label>
                  </div>
                  <div class="col-md-6">
                    <input type="text" name="fld_standard" class="form-control" value="<?php echo $row['fld_standard'] ?>"required>
                  </div>

               </div>



              <div class="row" style="padding-left:10%">
                  <div class="col-md-4">
                    <label>Premium</label>
                  </div>
                  <div class="col-md-6">
                    <input type="text" name="fld_premium" class="form-control" value="<?php echo $row['fld_premium'] ?>" required>
                  </div>

               </div>

             <div class="tab-custom-content" style="padding-left:20px">

             <button onclick="this.form.submit()" class="btn btn-dark btn-block" name="fld_price">Update Prices </button>
            </div>

             </form>



         


  

              </div>















             
            </div>
            
         
      
          </div>
        </div>

</div>






<?php 

}
}else{



}

?>

</div>

<!-- END MAIN -->
</div>

<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>























<!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer" align="center">
    <!-- To the right -->
  
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="index.php">Skillset</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

</body>
</html>
