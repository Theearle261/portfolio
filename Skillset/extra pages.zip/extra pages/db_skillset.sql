-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2024 at 05:04 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_skillset`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chat`
--

CREATE TABLE `tbl_chat` (
  `fld_chat_Id` int(11) NOT NULL,
  `fld_chat` varchar(1000) NOT NULL,
  `fld_sender` int(6) NOT NULL,
  `fld_receiver` int(6) NOT NULL,
  `fld_Date` datetime NOT NULL DEFAULT current_timestamp(),
  `fld_type` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_chat`
--

INSERT INTO `tbl_chat` (`fld_chat_Id`, `fld_chat`, `fld_sender`, `fld_receiver`, `fld_Date`, `fld_type`) VALUES
(44, 'hi anton', 2, 24, '2024-01-25 09:57:30', ''),
(45, 'Hi! This is an automated message, we will get back you in a while', 24, 2, '2024-01-25 09:57:30', ''),
(46, 'hello', 24, 2, '2024-01-25 09:57:49', ''),
(47, 'queen', 2, 3, '2024-01-25 09:58:18', ''),
(48, 'Hi! This is an automated message, we will get back you in a while', 3, 2, '2024-01-25 09:58:18', ''),
(49, 'busy?', 2, 24, '2024-01-25 10:00:06', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_entry`
--

CREATE TABLE `tbl_entry` (
  `fld_entry_Id` int(11) NOT NULL,
  `fld_description` varchar(300) NOT NULL,
  `fld_about` varchar(2000) NOT NULL,
  `fld_basic` int(5) NOT NULL,
  `fld_standard` int(6) NOT NULL,
  `fld_premium` int(6) NOT NULL,
  `fld_job_Id` int(6) NOT NULL,
  `fld_Id` int(6) NOT NULL,
  `fld_tags` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_entry`
--

INSERT INTO `tbl_entry` (`fld_entry_Id`, `fld_description`, `fld_about`, `fld_basic`, `fld_standard`, `fld_premium`, `fld_job_Id`, `fld_Id`, `fld_tags`) VALUES
(1, 'Taking Minimalist Visuals is my Passion', 'From the perspective of a freelance video editor, my POV is a symphony of creativity, autonomy, and the constant pursuit of visual storytelling excellence. Embracing the role of a digital storyteller, I relish the opportunity to bring ideas to life through the magic of editing. The freedom to choose projects aligns perfectly with my desire to explore diverse themes and industries, ensuring that no two editing experiences are the same. Each project is a canvas, and I thrive on the challenge of weaving together raw footage, music, and graphics to create a compelling narrative. The flexible schedule allows me to capitalize on peak creative moments, resulting in work that truly reflects my artistic vision. However, the flip side involves the juggle of client communications, project management, and the continuous pursuit of new opportunities. Yet, the satisfaction of seeing a video come together seamlessly and knowing that my craft has the power to captivate audiences keeps me passionate and driven in the ever-evolving landscape of freelance video editing.', 120, 250, 500, 11, 3, 'test'),
(7, 'I will design a minimalist poster', 'Embarking on the freelance journey as a Graphic Designer has been a dynamic and fulfilling experience. The autonomy to choose projects that align with my creative vision and personal style has allowed me to explore various design avenues. Every client interaction is a unique opportunity to understand their vision, translate ideas into captivating visuals, and deliver bespoke solutions that resonate with their brand identity. While the freedom to set my schedule and work from anywhere nurtures a sense of flexibility, the responsibility of managing the entire design process—from concept to delivery—has honed my project management skills. Navigating the ebb and flow of creative inspiration and client expectations, each project serves as a testament to the power of design in conveying messages and making an impact. The ever-evolving landscape of design trends keeps me inspired, pushing me to continuously refine my skills and stay at the forefront of industry innovation. In the world of freelance graphic design, each project is not just a task; it\'s a canvas for artistic expression, client collaboration, and the satisfaction of seeing ideas come to life.', 50, 100, 150, 12, 3, ''),
(8, 'I Create Amazing and High Quality Videos', 'Creating a high-quality video is a multifaceted endeavor that demands a meticulous approach and a fusion of technical expertise and creative vision. The process begins with a comprehensive pre-production phase, where careful planning, scriptwriting, and storyboard creation lay the foundation for a compelling narrative. Attention to detail in selecting the right equipment, such as high-resolution cameras and professional-grade audio recording tools, ensures top-notch production values. During the shoot, skilled cinematography, adept lighting techniques, and precise direction contribute to capturing visually stunning and engaging footage. Post-production, a critical phase, involves expert video editing, sound design, and color grading to enhance the overall visual and auditory experience. The seamless integration of graphics, animations, and any necessary special effects further elevates the video\'s production quality. The final product should not only meet technical standards but also resonate with the intended audience, conveying a compelling and memorable message. Achieving excellence in every stage of video production is paramount for delivering a high-quality and impactful visual masterpiece.', 150, 250, 400, 11, 24, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobs`
--

CREATE TABLE `tbl_jobs` (
  `fld_job_Id` int(11) NOT NULL,
  `fld_job` varchar(30) NOT NULL,
  `fld_motto` varchar(100) NOT NULL,
  `fld_pic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_jobs`
--

INSERT INTO `tbl_jobs` (`fld_job_Id`, `fld_job`, `fld_motto`, `fld_pic`) VALUES
(11, 'Video Editing', 'Engage your viewers', 'IMG-65ab757ae2a592.05176930.jpg'),
(12, 'Graphic Design', 'Color your dreams', 'IMG-65ab7593656588.26354100.jpg'),
(13, 'Web Design', 'Customize your website', 'IMG-65ab7c18b4b6a0.03324621.jpg'),
(14, 'Logo Design', 'Build your brand', 'IMG-65ab7c31e26844.64180707.jpg'),
(15, 'Content Writing', 'Share your thoughts', 'IMG-65ab7c53d578f0.06134321.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_orders`
--

CREATE TABLE `tbl_orders` (
  `fld_order_Id` int(11) NOT NULL,
  `fld_customer_Id` int(6) NOT NULL,
  `fld_entry_Id` int(6) NOT NULL,
  `fld_plan` varchar(20) NOT NULL,
  `fld_date` datetime NOT NULL DEFAULT current_timestamp(),
  `fld_status` varchar(10) NOT NULL DEFAULT 'Processing',
  `fld_amount` int(11) NOT NULL,
  `fld_rating` int(1) NOT NULL,
  `fld_review` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_orders`
--

INSERT INTO `tbl_orders` (`fld_order_Id`, `fld_customer_Id`, `fld_entry_Id`, `fld_plan`, `fld_date`, `fld_status`, `fld_amount`, `fld_rating`, `fld_review`) VALUES
(16, 2, 8, 'Standard', '2024-01-23 11:54:21', 'Closed', 500, 4, 'I love his work! He has sense of responsibility when it comes to transaction. He is recomendable!'),
(17, 2, 8, 'Premium', '2024-01-25 10:01:40', 'Processing', 400, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_portfolio`
--

CREATE TABLE `tbl_portfolio` (
  `fld_folio_Id` int(11) NOT NULL,
  `fld_picture` varchar(100) NOT NULL,
  `fld_entry_Id` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_portfolio`
--

INSERT INTO `tbl_portfolio` (`fld_folio_Id`, `fld_picture`, `fld_entry_Id`) VALUES
(5, 'skill.jpg', 5),
(6, 'web.jpg', 3),
(12, 'IMG-65af3b4e8d4e69.54112633.jpg', 1),
(13, 'IMG-65af3b5f973527.24372903.jpg', 1),
(15, 'IMG-65af3b72272779.36612155.jpg', 1),
(17, 'IMG-65af6461ee8267.60125552.jpg', 7),
(18, 'IMG-65af8d302702c6.52210439.jpg', 8),
(19, 'IMG-65af8d3c17c483.41258666.jpg', 8),
(21, 'IMG-65af8d5f525a04.89536191.jpg', 8),
(22, 'IMG-65af8d97e133a4.73376440.jpg', 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `fld_Id` int(11) NOT NULL,
  `fld_Lastname` varchar(30) NOT NULL,
  `fld_Firstname` varchar(30) NOT NULL,
  `fld_Status` varchar(15) NOT NULL DEFAULT 'Active',
  `fld_User_Level` varchar(10) NOT NULL DEFAULT 'Customer',
  `fld_Username` varchar(40) NOT NULL,
  `fld_Password` varchar(50) NOT NULL,
  `fld_Address` varchar(60) NOT NULL,
  `fld_Phone` varchar(20) NOT NULL,
  `fld_pic` varchar(200) NOT NULL DEFAULT 'default.jpg',
  `fld_rating` double(5,1) NOT NULL DEFAULT 5.0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`fld_Id`, `fld_Lastname`, `fld_Firstname`, `fld_Status`, `fld_User_Level`, `fld_Username`, `fld_Password`, `fld_Address`, `fld_Phone`, `fld_pic`, `fld_rating`) VALUES
(2, 'Wurtzbach', 'Pia', 'Active', 'Customer', 'cust@cust', 'cust', 'New York Citya', '87100000', 'IMG-65ae47724999a3.53431256.jpg', 0.0),
(3, 'Gray', 'Catriona', 'Active', 'Freelancer', 'cat@cat', 'cat', 'Manila', '34343433', 'IMG-65ae4a83657737.84495193.jpg', 5.0),
(5, 'L', 'Earl', 'Active', 'Admin', 'admin@admin', 'admin', 'dfd', 'fdfdf', 'default.jpg', 0.0),
(23, 'Lapuz', 'Earl Gerald', 'Active', 'Freelancer', 'fernandezearlgerald86@gmail.com', 'a', 'San Fernando City', '+639234367931', 'default.jpg', 5.0),
(24, 'Policarpio', 'Antonio', 'Active', 'Freelancer', 'antonio@gmail.com', 'antonio', 'Mumbai', '+91 22 1854 5978', 'IMG-65af8beb7ab8b8.79028235.jpg', 5.0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_chat`
--
ALTER TABLE `tbl_chat`
  ADD PRIMARY KEY (`fld_chat_Id`);

--
-- Indexes for table `tbl_entry`
--
ALTER TABLE `tbl_entry`
  ADD PRIMARY KEY (`fld_entry_Id`);

--
-- Indexes for table `tbl_jobs`
--
ALTER TABLE `tbl_jobs`
  ADD PRIMARY KEY (`fld_job_Id`);

--
-- Indexes for table `tbl_orders`
--
ALTER TABLE `tbl_orders`
  ADD PRIMARY KEY (`fld_order_Id`);

--
-- Indexes for table `tbl_portfolio`
--
ALTER TABLE `tbl_portfolio`
  ADD PRIMARY KEY (`fld_folio_Id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`fld_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_chat`
--
ALTER TABLE `tbl_chat`
  MODIFY `fld_chat_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tbl_entry`
--
ALTER TABLE `tbl_entry`
  MODIFY `fld_entry_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_jobs`
--
ALTER TABLE `tbl_jobs`
  MODIFY `fld_job_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_orders`
--
ALTER TABLE `tbl_orders`
  MODIFY `fld_order_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_portfolio`
--
ALTER TABLE `tbl_portfolio`
  MODIFY `fld_folio_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `fld_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
