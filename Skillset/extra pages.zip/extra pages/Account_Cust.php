<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->

<?php 

include 'config.php';
require('session.php');

?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Skillset</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

   <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">

  <link rel="icon" type="image/x-icon" href="assets/images/icon.png">
</head>
<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
<?php 



include('Navbar_Cust.php');


?>
  <!-- /.navbar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <br/><br/><br/>
  
    <section class="content">

      <div class="container">
  <h2>Account Details</h2>
<?php

$fld_Id=$_SESSION['login_user'];
       $sql = "SELECT * FROM tbl_user Where fld_Id='$fld_Id' ";
          $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {


      ?>
      
      <div class="row">

        <div class="col-md-3">

      <img src="assets/images/users/<?php echo $row['fld_pic']  ?>" style="border-radius: 50%; height: 250px;"/>
      <br/>
   <form method ="POST" action="Update_Pic.php" enctype="multipart/form-data" >
  <div class="custom-file" align="center" style="overflow: hidden; height: 100px;"  >
     <div class="form-group row">
 <input type="hidden" name="fld_Id" value="<?php echo $row['fld_Id'] ?>">
   <input type="hidden" name="fld_User_Level" value="<?php echo $row['fld_User_Level'] ?>">
    </div>
     
                        <input type="file" name="fld_pic"  class="btn-lg btn-warning"   onchange="form.submit()">
                        <label  ><p>Replace Photo</p></label>
                      </div>


                <br/>
                <br/>

              </form>
      </div>

        <div class="col-md-6">

          <form method="POST" action="Update_User.php">

          <input type="hidden" name="fld_Id" value="<?php echo $row['fld_Id'] ?>">
            <input type="hidden" name="fld_User_Level" value="<?php echo $row['fld_User_Level'] ?>">
        <div class="form-group">
                <label for="inputProjectLeader">Firstname</label>
                <input class="form-control" type="text" value="<?php echo $row['fld_Firstname']  ?>" name="fld_Firstname" required>
        </div>

        <div class="form-group">
                <label for="inputProjectLeader">Lastname</label>
                <input class="form-control" type="text" value="<?php echo $row['fld_Lastname']  ?>" name="fld_Lastname" required>
        </div>


        <div class="form-group">
                <label for="inputProjectLeader">Username</label>
                <input class="form-control" type="email" value="<?php echo $row['fld_Username']  ?>" name="fld_Username" required>
        </div>

        <div class="form-group">
                <label for="inputProjectLeader">Password</label>
                <input class="form-control" type="Password" value="<?php echo $row['fld_Password']  ?>" name="fld_Password" required>
        </div>

          <div class="form-group">
                <label for="inputProjectLeader">City</label>
                <input class="form-control" type="text" value="<?php echo $row['fld_Address']  ?>" name="fld_Address" required>
        </div>

          <div class="form-group">
                <label for="inputProjectLeader">Phone Number</label>
                <input class="form-control" type="text" value="<?php echo $row['fld_Phone']  ?>" name="fld_Phone" required>
        </div>


        <input type="submit" value="Update" class="btn btn-dark">

      </form>



         
        </div>
      <br/>
      

  
<?php 


}

?>

</div>
</section>

    
    <!-- /.content-header -->

  <!-- /.container-fluid -->
    </div>
  </body>
  </html>
    <!-- /.content -->

  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer" align="center">
    <!-- To the right -->
  
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="index.php">Skillset</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>

</body>
</html>
