<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->

<?php 

include 'config.php';
include('session.php');


?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Skillset</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">


  <link rel="icon" type="image/x-icon" href="assets/images/icon.png">
</head>
<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
  <?php
include('Navbar_Free.php');


?>
  <!-- /.navbar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">

      <br/>  <br/>
     
     
            <ol class="breadcrumb" style="padding-left: 20%;">
              <li class="breadcrumb-item"><a href="index.php#services"><i class="fa fa-home"></i></a></li>
             
                  <li class="breadcrumb-item active">Order History</li>
            </ol>
         <div class="container">
          <div class="card">
            <table id="example2" class="table table-bordered table-hover dataTable dtr-inline" aria-describedby="example2_info">
                  <thead>
                 <tr><th class="sorting sorting_asc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Date</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">Item</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">Customer</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending">Plan</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending">Amount</th>
                    <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending">Status</th>
                    <th>Rating & Review</th>

                    </tr>
                  </thead>
                  <tbody>

                             <?php
$fld_Id=$_SESSION['login_user'];
      



if (isset($_POST['done'])) {


    $fld_order_Id=$_POST['fld_order_Id'];


    $sqlq ="UPDATE tbl_orders SET fld_status='Done' WHERE fld_order_Id='$fld_order_Id'";


if ($conn->query($sqlq) === TRUE) {

?>
 <script type="text/javascript">
window.onload = function(){
     
$(document).ready(function () {
    // Handler for .ready() called.
    window.setTimeout(function () {
        location.href = "Todo.php";
    }, 3000);

            Swal.fire(
 'Marked as Done!',
    '',
  'success'
)
});

} </script>

     <?php

}else{

      echo "<td>Error Updating record: " . mysqli_error($conn);
}

}


$sql = "SELECT * FROM  tbl_user inner join tbl_orders on tbl_orders.fld_customer_Id=tbl_user.fld_Id inner join tbl_entry on tbl_entry.fld_entry_Id=tbl_orders.fld_entry_Id inner join tbl_jobs on tbl_jobs.fld_job_Id=tbl_entry.fld_job_Id  where tbl_entry.fld_Id='$fld_Id' and tbl_orders.fld_status!='Processing' order by tbl_orders.fld_date DESC ";


        $result = mysqli_query($conn,$sql);
 $rowcount=mysqli_num_rows($result);


                      while($row = mysqli_fetch_assoc($result)) {

                        $date=$row['fld_date'];

                      

 ?>
                  <tr class="odd">
                    <td ><?php echo date('F j, Y H:i', strtotime($date)) ?></td>
                    <td><?php echo $row['fld_job'] ?></td>


                    <td><?php echo $row['fld_Firstname']." ". $row['fld_Lastname']; ?></td>
                    <td><?php echo  $row['fld_plan']; ?></td>
                        <td><?php echo "₹". $row['fld_amount']; ?></td>
                   <td style="color:green"><?php echo  $row['fld_status']; ?></td>
                    <td><i class="fa fa-star" style="color:gold;"></i><?php echo  $row['fld_rating']; ?>.0 - <?php echo  $row['fld_review']; ?>
                   </td>
                   
                  </tr>


                  <?php 


                }

                ?>

                </tbody>
                
                </table>





          </div>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer" align="center">
    <!-- To the right -->
  
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="index.php">Skillset</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

</body>
</html>
