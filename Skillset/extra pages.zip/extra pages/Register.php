<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Skillset | Register</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

   <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
    <link rel="icon" type="image/x-icon" href="assets/images/icon.png">
</head>
<body class="hold-transition login-page" style="background-image:url('assets/images/bg.png'); background-repeat:no-repeat ; background-size: 110%;" >
<div class="login-box">
  <div class="login-logo">
    <a href="index.php"><img src="assets/images/icon.png" height="50px"></a>
  </div>
  <!-- /.login-logo -->
<?php
 include("config.php");
   session_start();
?>





  <div class="row">


    <div class="col-md-12">
  <div class="card">
    <div class="card-body login-card-body">
          <a href="index.php"><img src="assets/images/skillset.png" height="50px" style="padding-left: 20%;"></a>

          <br/>
          <br/>

      <form action="Sign_Up.php" method="post">


         <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="Lastname" name="fld_Lastname" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>



         <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="Firstname" name="fld_Firstname" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>


        <div class="input-group mb-3">
          <input type="email" class="form-control" placeholder="Email" name="fld_Username" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Password" name="fld_Password" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>


         <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="City" name="fld_Address" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-home"></span>
            </div>
          </div>
        </div>

         <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="Phone" name="fld_Phone" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-phone"></span>
            </div>
          </div>
        </div>

         <div class="input-group mb-3">
          
  <div class="input-group-append">
          <div class="row" >

            <div class="col-md-6">
        
             <label style="font-size: 15px; padding-left: 10%;" >I want to become a</label>

           </div>

           <div class="col-md-6">
            <div class="custom-control custom-radio">
                          <input class="custom-control-input" type="radio" id="customRadio1" value="Freelancer" name="fld_User_Level" required >
                          <label for="customRadio1" class="custom-control-label">Freelancer</label>
                        
                        </div>
                        
                          <div class="custom-control custom-radio">


                          <input class="custom-control-input" type="radio" id="customRadio2" value="Customer" name="fld_User_Level" required >
                          <label for="customRadio2" class="custom-control-label">Customer</label>
             
            </div>
          </div>
          </div>
        </div>
      </div>










        <div class="row">


         
          <!-- /.col -->
          <div class="col-12">

            <div class="custom-control custom-checkbox">
                          <input class="custom-control-input" type="checkbox" id="customCheckbox2" required>
                          <label for="customCheckbox2" class="custom-control-label" style="font-size:10px" >By checking this, you acknowledge that you have read and agree to the Terms of Service and Privacy Policy. You understand and consent to the collection and processing of your personal information in accordance with the privacy practices outlined in our policy. </label>
                        </div>

                        <br/>
            <button type="submit" class="btn btn-dark btn-block">Create Account</button>
          </div>
          <!-- /.col -->
        </div>
      </form>
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
